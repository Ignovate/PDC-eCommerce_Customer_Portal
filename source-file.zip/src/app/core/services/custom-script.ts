declare var $:any;
export class CustomScript{
    constructor() {        
    }
    loadScript(){
    $.getScript('assets/js/vendor/jquery-1.12.4.min.js');
    $.getScript('assets/js/imagesloaded.pkgd.min.js');
    $.getScript('assets/js/isotope.pkgd.min.js');
    $.getScript('assets/js/jquery-ui.min.js');
    $.getScript('assets/js/waypoints.min.js');
    $.getScript('assets/js/owl.carousel.min.js');
    $.getScript('assets/js/slick.min.js');
    // $.getScript('assets/js/jquery.nice-select.min.js');
    $.getScript('assets/js/jquery.meanmenu.min.js');
    $.getScript('assets/js/instafeed.min.js');
    $.getScript('assets/js/jquery.scrollUp.min.js');
    $.getScript('assets/js/wow.min.js');
    $.getScript('assets/js/venobox.min.js');
    $.getScript('assets/js/wow.min.js');
    $.getScript('assets/js/popper.min.js');
    $.getScript('assets/js/bootstrap.min.js');
    $.getScript('assets/js/plugins.js');
    $.getScript('assets/js/main.js');
    }
}