import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { CustomScript } from '../core/services/custom-script';
import { HyperService } from '../core/services/http.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { LocalStore } from '../store/local-store';
import { Util } from '../util/util';
declare var $: any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  
  isLogged: boolean;
  salesOrderList: any = [];
  salesQuote_data: any;
  salesQuotePrice: any = [];
  totalQuantity: any;
  productId: any;
  imageUrl: any = "http://167.99.153.79:8080/gaia_ecom_admin/gaiafiles?form=product";
  imageSrc: any = [];
  userData: any = [];
  salesOrderData: any;
  fieldName: any;
  text_value: any;
  quote_data:any;
  quoteId:any;
  input:any;

  constructor(private router: Router,
    private activatedroute:ActivatedRoute,
    private customs: CustomScript,
    private server: HyperService) {
    this.customs.loadScript()
    // this.salesQuote_data = LocalStorage.getValue('salesQuoteItems');
  }

  ngOnInit() {
    if(LocalStore.get("loggedIn")) {
      this.input = LocalStore.getAndRemove("cart");
      if(this.input) {
        this.addToCart(this.input);
      } else if(LocalStore.get("quoteId")) {
        this.server.get("cart/read?quoteId="+LocalStore.get("quoteId"))
            .then((data) => {
            console.log("cart", data);
            if (data.status == 200) {
              this.salesOrderData = data.result;
              this.salesOrderList = data.result.quoteOrderItems;
              LocalStore.add('quoteId', this.salesOrderData.id);
            }
            else {
  
            }
          });
      } else {
        console.log("input not available");
        this.router.navigateByUrl('');
      }
    } else {
      this.router.navigateByUrl('login');
    }
  }

  goToContinue() {
    if (this.isLogged) {
      this.router.navigateByUrl('')
    } else {
      this.router.navigateByUrl('login')
    }
  }
  
  placeOrder() {
    this.router.navigateByUrl('checkout');
  }

  addToCart(params) {
    this.server.post("cart/new", params)
      .then((data) => {
        console.log(data)
        if (data.status == 200) {
          this.salesOrderData = data.result;
          this.salesOrderList = data.result.quoteOrderItems;
          LocalStore.add('quoteId', this.salesOrderData.id);
          LocalStore.add("cartItemCount", data.result.totalItems);
        }
        else {

        }
    });
  }

  updateToCart(params) {
    this.server.post("cart/update", params)
      .then((data) => {
        console.log(data)
        if (data.status == 200) {
          this.salesOrderData = data.result;
          this.salesOrderList = data.result.quoteOrderItems;
          LocalStore.add('quoteId', this.salesOrderData.id);
          LocalStore.add('quoteId', this.salesOrderData.id);
          LocalStore.add("cartItemCount", data.result.totalItems);
        }
        else {

        }
    });
  }

  removeFromCart(productId){
    this.server.post("cart/delete", Util.buildCartParam(productId, 0))
      .then((data) => {
        console.log(data)
        if (data.status == 200) {
          this.salesOrderData = data.result;
          this.salesOrderList = data.result.quoteOrderItems;
          LocalStore.add('quoteId', this.salesOrderData.id);
          LocalStore.add("cartItemCount", data.result.totalItems);
        }
        else {

        }
    });
  }

  increaseQuantity(productId, quantity) {
    this.updateToCart(Util.buildCartParam(productId, quantity));
  }

  decreaseQuantity(productId, quantity) {
    this.updateToCart(Util.buildCartParam(productId, quantity));
  }

}
